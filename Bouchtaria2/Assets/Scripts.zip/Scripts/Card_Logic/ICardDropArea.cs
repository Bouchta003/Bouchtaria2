using UnityEngine;

public interface ICardDropArea {
    void OnCardDrop(Card card);
}
