﻿using UnityEngine;
using TMPro;
using UnityEngine.UI;
using Firebase.Auth;
using UnityEngine.EventSystems;

public class LoginUIController : MonoBehaviour
{
    [Header("Inputs")]
    [SerializeField] private TMP_InputField emailInput;
    [SerializeField] private TMP_InputField passwordInput;
    [SerializeField] private Button createAccountButton;
    [SerializeField] private TMP_Text uidText;
    private string lastUserId;
    [SerializeField] private GameObject successfullConnection;
    void Start()
    {
        EventSystem.current.SetSelectedGameObject(emailInput.gameObject);
    }
    void Update()
    {
        FirebaseUser user = AuthManager.Instance.CurrentUser;

        if (user == null)
        {
            if (!string.IsNullOrEmpty(lastUserId))
            {
                uidText.text = "Not connected";
                lastUserId = null;
                successfullConnection.SetActive(false);
            }
            return;
        }
        successfullConnection.SetActive(true);

        if (user.UserId != lastUserId)
        {
            lastUserId = user.UserId;

            uidText.text = user.IsAnonymous
                ? $"{user.UserId}"
                : $"{user.Email}";

            Debug.Log("🔄 Auth UI updated");
        }
    }
    public void OnGuestClicked()
    {
        AuthManager.Instance.Initialize();
    }

    public void OnCreateAccountClicked()
    {
        AuthManager.Instance.CreateOrLinkAccount(
               emailInput.text,
               passwordInput.text
           );
    }
    public void PlayButton()
    {
        if (AuthManager.Instance.CurrentUser != null)
        {
            GameFlowController.Instance.GoToMainMenu();
        }
    }


    public void OnLoginClicked()
    {
        AuthManager.Instance.SignInWithEmail(
            emailInput.text,
            passwordInput.text
        );
    }
}
