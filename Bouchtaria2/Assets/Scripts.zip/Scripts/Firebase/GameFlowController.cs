﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class GameFlowController : MonoBehaviour
{
    public static GameFlowController Instance { get; private set; }

    private bool cardsReady;
    public bool IsGameReady = false;
    private bool collectionReady;

    private void Awake()
    {
        if (Instance != null)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    // 🔹 Called after auth succeeds
    public void InitializeGameData(string uid)
    {
        ResetForNewUser();

        CardDatabase.Instance.OnCardsLoaded += OnCardsLoaded;
        UserCollectionManager.Instance.OnCollectionReady += OnCollectionReady;

        if (!CardDatabase.Instance.IsReady)
            CardDatabase.Instance.Initialize();
        else
            OnCardsLoaded();

        UserCollectionManager.Instance.Initialize(uid);
    }


    public void ResetForNewUser()
    {
        cardsReady = false;
        collectionReady = false;

        CardDatabase.Instance.OnCardsLoaded -= OnCardsLoaded;
        UserCollectionManager.Instance.OnCollectionReady -= OnCollectionReady;
    }

    private void OnCardsLoaded()
    {
        cardsReady = true;
        TryMarkGameReady();
    }

    private void OnCollectionReady()
    {
        collectionReady = true;
        TryMarkGameReady();
    }

    private void TryMarkGameReady()
    {
        if (cardsReady && collectionReady)
        {
            IsGameReady = true;
            Debug.Log("✅ Game data fully ready");
        }
    }


    // 🔹 UI-driven navigation
    public void GoToMainMenu()
    {
        SceneManager.LoadScene("Main_Menu");
    }
    public void GoToTitleScreen()
    {
        SceneManager.LoadScene("Firebase");
    }

    public void GoToCollection()
    {
        if (!cardsReady || !collectionReady)
        {
            Debug.LogWarning("⚠️ Game data not ready yet");
            return;
        }

        SceneManager.LoadScene("Collection");
    }
}
